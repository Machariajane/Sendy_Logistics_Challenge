Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Sat 07 May 2022 09:12:49 AM UTC
GPS rectangle coordinates (lng,lat): 36.633,-1.415 x 37.037,-1.149
Script URL: https://extract.bbbike.org?sw_lng=36.633&sw_lat=-1.415&ne_lng=37.037&ne_lat=-1.149&format=shp.zip&city=Nairobi_1&lang=en
Name of area: Nairobi_1


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 10 Euro (12 USD) by the end of the day or
300 Euro (350USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
